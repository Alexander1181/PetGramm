package com.petgram.auth_service.controller;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;
@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*") // Permite peticiones desde cualquier lado
public class AuthController {
    // Simulación de base de datos en memoria (simple)
    private Map<String, String> usersDb = new HashMap<>();
    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody Map<String, String> userData) {
        String email = userData.get("email");
        String password = userData.get("password");
        if (usersDb.containsKey(email)) {
            return ResponseEntity.badRequest().body("Error: El usuario ya existe");
        }
        usersDb.put(email, password);
        return ResponseEntity.ok("Usuario registrado con éxito: " + email);
    }
    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody Map<String, String> loginData) {
        String email = loginData.get("email");
        String password = loginData.get("password");
        if (usersDb.containsKey(email) && usersDb.get(email).equals(password)) {
            // En un caso real, aquí devolveríamos un Token JWT
            return ResponseEntity.ok("LOGIN_EXITOSO_TOKEN_FALSO_12345");
        }
        
        return ResponseEntity.status(401).body("Error: Credenciales inválidas");
    }
}